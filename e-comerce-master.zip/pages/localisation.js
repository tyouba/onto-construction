/**
 * /* eslint-disable jsx-a11y/alt-text
 *
 * @format
 */

/**
 * /* eslint-disable jsx-a11y/alt-text
 *
 * @format
 */

/**
 * /* eslint-disable jsx-a11y/alt-text
 *
 * @format
 */

/* eslint-disable @next/next/no-img-element */
/* eslint-disable @next/next/no-html-link-for-pages */
/** @format */

import React from 'react';

export function Localisation(props) {
	return (
		<>
			{' '}
			<br />
			<marquee behavior='scroll'>
				<h3 className='u'> Localisation</h3>
			</marquee>{' '}

			<br />
			<div className='lo'>
				<div className='container  '>
					<div className='row'>
						<iframe
							className='img'
							src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d88518.6664600316!2d3.572744825337387!3d46.106755666026096!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f6b473ef092e9d%3A0x201851e5bea15bd2!2s03250%20Nizerolles%2C%20France!5e0!3m2!1sfr!2stn!4v1625569068636!5m2!1sfr!2stn'
							width='600'
							height='450'
							loading='lazy'></iframe>
					</div>{' '}
					<br /> <br />
					<div className='row'>
						<iframe
							className='img'
							src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d361836.56324149354!2d-1.0617863129081844!3d44.88573909291393!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54ce52a50fce4f%3A0x40665174816d580!2s33160%20Saint-M%C3%A9dard-en-Jalles%2C%20France!5e0!3m2!1sfr!2stn!4v1625569255494!5m2!1sfr!2stn'
							width='600'
							height='450'
							loading='lazy'></iframe>
					</div>
				</div>
			</div>
		</>
	);
}
export default Localisation;
