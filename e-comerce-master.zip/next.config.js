/** @format */


module.exports = {
	env: {
		BASE_URL: 'https://e-comerce.vercel.app/',
		MONGODB_URL:
			'mongodb+srv://khouloud:khouloud@cluster0.y8j09.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
		ACCESS_TOKEN_SECRET: 'khouloud602999301.3598777',
		REFRESH_TOKEN_SECRET: 'khouloud319238867623895khouloud.75',
		PAYPAL_CLIENT_ID:
			'ASIBTB4aRGsRqJClaSTNvXmk0u7nWuzQrvrEQIuKJtKz3-Z_Q_v4PR0azTk3BjWeI4yy6PciqG16_Q4w',
		CLOUD_UPDATE_PRESET: 'projet',
		CLOUD_NAME: 'msaken',
		CLOUD_API: 'https://api.cloudinary.com/v1_1/msaken/image/upload',
	},
};
